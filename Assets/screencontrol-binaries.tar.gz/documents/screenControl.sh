#!/bin/sh
# Name: Start screenControl
# Author: Marek (lab126)
# Icon:
killall screenControl &> /dev/null
killall screenControlHF &> /dev/null
ip_addr=$(ifconfig | grep -Eo 'inet (addr:)?([0-9]*\.){3}[0-9]*' | grep -Eo '([0-9]*\.){3}[0-9]*' | grep -v '127.0.0.1')

echo "screenControl started on: http://$ip_addr:6789"

iptables -A INPUT -p tcp --dport 6789 -j ACCEPT

if [ -f /lib/ld-linux-armhf.so.3 ]; then
 /mnt/us/extensions/screenControl/screenControlHF &
else
 /mnt/us/extensions/screenControl/screenControl &
fi

sleep 5
exit 0